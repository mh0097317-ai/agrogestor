# StudioFlow: pacote de transferência (25/11/2026)

Auditoria completa do StudioFlow para a equipe que vai assumir a gestão estratégica e as próximas missões.

## Ordem de leitura sugerida
1. `STUDIOFLOW_RELATORIO_FINAL.md`: resumo executivo, onde paramos, notas, 10 problemas e 10 oportunidades, concorrência com fontes, testes executados.
2. `STUDIOFLOW_CONHECIMENTO_COMPLETO.md`: produto, jornadas, histórico, auditoria de cada tela, agenda, recepcionista IA, automações, financeiro, CRM, SaaS.
3. `STUDIOFLOW_MATRIZ_FUNCIONAL.md`: o que funciona, o que é parcial, simulado, depende de credencial ou não existe.
4. `STUDIOFLOW_ROADMAP.md`: ondas 0 a 3 para execução autônoma.
5. `STUDIOFLOW_ARQUITETURA.md`, `STUDIOFLOW_INTEGRACOES.md`, `STUDIOFLOW_SEGURANCA.md`: parte técnica.
6. `STUDIOFLOW_AUDITORIA_VISUAL.md` + pasta `capturas/` (comece pelas folhas `_folha-*.jpg`).
7. `STUDIOFLOW_GUIA_DO_USUARIO.md`: como cada função é usada.

## Pastas
- `capturas/`
  - `NN-tela-desktop.jpg` / `NN-tela-mobile.jpg`: 94 capturas do modo demonstração, só com dados fictícios;
  - `P0`/`P1`: 4 capturas públicas da produção;
  - `_folha-*`: visão geral.
- `capturas-historicas/`: visual em 02/10 (editorial), em 03/10 (referência) e a referência original.
- `diagramas/`: Mermaid (`.mmd`) da arquitetura, dos relacionamentos do banco e do fluxo do WhatsApp.
- `evidencias/`: resumos de testes, smoke, tipos, lint, audit, build e ocorrências das capturas.

## O que NÃO está neste pacote (de propósito)
- Credenciais, arquivos `.env`, tokens, cookies, chaves privadas.
- Dumps ou dados reais de clientes (o banco foi lido apenas em contagens agregadas).
- O código-fonte, que fica no GitHub: `mh0097317-ai/studioflow` (branch `main`). O espelho histórico está em `mh0097317-ai/agrogestor`, pasta `studioflow/`.

## Endereços
- App em produção: https://app.studioflowapp.tech
- Demonstração: botão "Ver demonstração ao vivo" no site.
